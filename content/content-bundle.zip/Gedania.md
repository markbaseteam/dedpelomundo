---
tipo: NPC
posicionamento: 
dg-publish: true
---
[[Home]] | [[Etiei]] | [[Log do dia 4720-08-02]] 
# [[Gedania]]
nome: Gedania
raça: elfo
idade: 38 (8 em humano)

### primeiro contato
local: [[Etiei]]
circunstância: Mora com os avós de [[Aladrail]] ([[Aramil Duoborn]] e [[Anastriana Duoborn]])

### outras informações


---
[[personagem]] [[NPC]] 
