---
dg-publish: true
tipo: jogador
jogador: Renato
alinhamento:
 - caotico
 - neutro
classe: Feiticeiro
Deus: Ehlonna
nivel: 12
HP: 75
AC: 14
Initiative: 2
outros_personagens: Aguia
Condicao: 
---
%%
[[personagem]] [[jogadores]]
tags: 
%%

# [[Aladrail]]
<span class="rightimg"><span class="mediumimg">![[AladrailProfilePic.jpeg]]</span></span>nome: Aladrail Duoborn
Raça: [[Meio-Elfo]]
Classe: [[feiticeiro]]
Deus: [[Ehlonna]]
Alinhamento: Caótico neutro
Nível: 12

sobrinho do [[Lhoris]]

## História
Filho de um elfo com humana... nunca se encaixou em lugar nenhum

havia um talento inato à magia

convivia bem com os humanos mas tomou ranço contra a tirania que imôos aquele tipo de comportamento

para não entrar no exército havia feito um plano, mas [[Li]] e [[Lhoris]] o encontraram antes e ofereceram uma vida de aventura contra a tirania.
