---
tipo: NPC
posicionamento: follower
dg-publish: true
---
[[Home|Home]] | [[Enoch]] | [[triade|Tríade]] 
# [[Josias]] ([[Ficha Auxiliar Josias|Ficha]])
<span class="rightimg"><span class="smallimg">![[josiasProfilePic.jpeg]]</span></span>**nome**: Josias
**alias**: 
**raça**: Humano
**idade**: 55
**atividade**: Clérigo de [[Pelor]]
**descrição**: 

### primeiro contato
**local**: [[Cidade de Nemis]]
**circunstância**: Ajudou a tríade na luta contra o [[Nemis - O demonio]].

### outras informações
Clérigo de [[Pelor]]
Dominios: Good, Healing

### História
Josias terminou seu treinamento de clérigo de [[Pelor]] aos 21 anos de idade, e sempre se mostrou muito promissor.

Aos 30 anos já era conhecido por toda a [[Teia]] por seus feitos e poder. Muitos acreditavam que em seu futuro estava a cadeira do Sumo sacerdote de [[Pelor]].

Porém, como [[Nimbi]] já havia dito, é impossível prever o futuro com exatidão, e um simples bater de asas de um borboleta, pode gerar ramificações inimagináveis e de enormes proporções.

Quando ele tinha 37 anos de idade, o seu poder e sua fama eram tamanhos, que muitos malfeitores ao ouvirem que [[Josias]] havia sido designado para "lidar com eles", já abandonavam os seus esquemas e fugiam. 

Isso, no entanto, fez com que [[Josias]] começasse a ser descuidado, e arrogante.

Talvez arrogância não seja a palavra correta para descrever seu comportamento, uma vez que ele sempre fez questão de ser tratado igual a todos ao seu redor, mas o fato é que ele começou a não levar os seus oponentes tão a sério. Lentamente, ele foi cada vez mais se sentindo certo da vitória, antes mesmo de encontrar seus adversários. 

Ele se sentia invencível! 

Até o dia em que ele subestimou o adversário errado e toda sua vida mudou completamente.

Os eventos do dia que mudou a vida de [[Josias]] foram tão dramáticos, e causaram um trauma tão profundo nele, que mesmo hoje, quase 20 anos após o ocorrido, ele mal é capaz de conversar sobre o que aconteceu, muito menos de relatar os fatos. E como ele foi o único sobrevivente, os detalhes continuam um mistério para todos.

O que se sabe, porém, é que naquele dia um imensa energia foi liberada por [[Josias]], ou por algo/alguém muito próximo do lugar onde ele foi encontrado. 

Ao serem despachados clérigos e paladinos para averiguar a explosão de energia divina, [[Josias]] foi encontrado, em pé, imóvel, no centro de uma vila completamente destruída. A área de destruição se estendia por vários quilómetros, e por onde se andava era possível ver corpos espalhados, alguns completamente esquartejados... irreconhecíveis. 

Desde este dia [[Josias]] está imbuído de uma magia [[Sanctuary|santuário]] poderosíssima, não sendo capaz de atacar e nem ser atacado fisicamente por nenhuma criatura. Além disso, todo o seu conhecimento prático de magia de batalha parece ter simplesmente sumido de sua mente. 

Ele *conhece* todas as magias, porém não é capaz de conjurá-las... As palavras não lhe vêem a mente na hora, suas mãos simplesmente se negam a fazer os gestos necessários...

Durante os primeiros 2 anos após o ocorrido, [[Josias]] foi para o santuário de [[Pelor]] localizado na cidade de Nemis, e se afastou de todos os seus conhecidos. Neste período ele se manteve em oração a maior parte do tempo. Comia o mínimo necessário para se manter vivo, e mesmo assim apenas por insistência de outros clérigos e colegas do santuário onde ele se refugiou.

Com o passar do tempo, aos poucos ele foi retomando as suas responsabilidades como clérigo de [[Pelor]]. Completados 13 anos do ocorrido, ele começou a ser capaz de ficar próximo de batalhas para fornecer cura aos seus aliados e outras ajudas necessárias. Eventualmente ele voltou a sorrir, a interagir com outras pessoas da cidade fora do templo, até que, para quem não o conhecia antes, ele parecia levar uma vida completamente normal.

Passados 17 anos, o seu poder era apenas uma fração do que já fora um dia, contudo [[Josias]] estava perfeitamente contente com sua vida.

Mas o destino ainda não havia terminado com [[Josias]], e o seu contentamento durou apenas até o dia em que a sua cidade voltou a ser ameaçada por [[Nemis - O demonio]]. 

Nos dias que antecederam o ataque em si, a cidade começou a ser assolada por demonios menores, e o sofrimento e a dor assolaram a sua cidade. 

[[Josias]] presenciado todo o sofrimento, começou a ficar cada dia mais incomodado com o sofrimento ao seu redor. Sua inabilidade de fazer qualquer coisa contra esse mal começou a "comê-lo vivo", de tal forma que ele já não conseguia mais dormir a noite. 

Ele, que já fora um dos maiores guerreiros de [[Teia]], agora mal era capaz de segurar uma maça. E, por causa de sua fraqueza, o Demonio iria destruir sua cidade sem que ele conseguisse levantar um dedo para evitar.

Quando o demônio chegou de fato à cidade ele já não aguentava mais. Precisava fazer ALGO, qualquer coisa para impedir este mal terrível.

Ele não aguentava mais se sentir um inútil.

Se lembrou que há alguns dias ficara sabendo do grupo de grandes aventureiros hospedados no templo de [[Heironeous]] e que buscavam uma forma de impedir Nemis. Saiu em disparada para lá decidido que iria fazer de tudo para ajudá-los nessa batalha.

Pouco tempo depois ele se juntou à tríade.


## Magias
### Domínio Healing
- [ ] [[Cure Light Wounds|Cure Light Wounds]] [preparada::1]  %%[healing::1]%% 
	- Cures 1d8 damage +1/level (max +5).  
- [ ] [[Cure Moderate Wounds|Cure Moderate Wounds]] [preparada::1]  %%[healing::2]%% 
	- Cures 2d8 damage +1/level (max +10).  
- [ ] [[Cure Serious Wounds|Cure Serious Wounds]] [preparada::1]  %%[healing::3]%% 
	- Cures 3d8 damage +1/level (max +15).  
- [ ] [[Cure Critical Wounds|Cure Critical Wounds]] [preparada::1]  %%[healing::4]%% 
	- Cures 4d8 damage +1/level (max +20).  
- [ ] [[Cure Light Wounds, Mass|Cure Light Wounds, Mass ]] [preparada::1]  %%[healing::5]%% 
	- Cures 1d8 damage +1/level for one creature/level, no two of which can be more than 30 [[ft]]. apart.  
- [ ] [[Heal|Heal]] [preparada::0]  %%[healing::6]%% 
	- Cures 10 points/level of damage, all diseases and mental conditions.  
- [ ] [[Regenerate|Regenerate]] [preparada::0]  %%[healing::7]%% 
	- Subject’s severed limbs grow back, cures 4d8 damage +1/level (max +35).  
- [ ] [[Cure Critical Wounds, Mass|Cure Critical Wounds, Mass]] [preparada::0]  %%[healing::8]%% 
	- Cures 4d8 damage +1/level for many creatures.  
- [ ] [[Heal, Mass|Heal, Mass]] [preparada::0]  %%[healing::9]%% 
	- As heal, but with several subjects.  

### Dominio Good
- [ ] [[Protection from Evil|Protection from Evil]] [preparada::0] 
	- +2 to AC and saves, counter mind control, hedge out elementals and outsiders.  
- [ ] [[Aid|Aid]] [preparada::0] 
	- +1 on attack rolls and saves against fear, 1d8 temporary hp +1/level (max +10).  
- [ ] [[Magic Circle against Evil|Magic Circle against Evil]] [preparada::0] 
	- As protection from evil, but 10-[[ft]]. radius and 10 min./level.  
- [ ] [[Holy Smite]] [preparada::0] 
	-  
- [ ] [[Dispel Evil|Dispel Evil]] [preparada::0] 
	- +4 bonus against attacks by evil creatures.  
- [ ] [[Blade Barrier|Blade Barrier]] [preparada::0] 
	- Wall of blades deals 1d6/level damage.  
- [ ] [[Holy Word|Holy Word]] [preparada::0] 
	- Kills, paralyzes, blinds, or deafens nongood subjects.  
- [ ] [[Holy Aura|Holy Aura]] [preparada::0] 
	- +4 to AC, +4 resistance, and SR 25 against evil spells.  
- [ ] [[Summon Monster IX|Summon Monster IX]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  

### Level 00
- [ ] [[Create Water|Create Water]] [preparada::0] 
	- Creates 2 gallons/level of pure water.  
- [ ] [[Cure Minor Wounds|Cure Minor Wounds]] [preparada::0] 
	- Cures 1 point of damage.  
- [ ] [[Detect Magic|Detect Magic]] [preparada::1] 
	- Detects spells and magic items within 60 [[ft]].  
- [ ] [[Detect Poison|Detect Poison]] [preparada::1] 
	- Detects poison in one creature or small object.  
- [ ] [[Guidance|Guidance]] [preparada::0] 
	- +1 on one attack roll, saving throw, or skill check.  
- [ ] [[Inflict Minor Wounds|Inflict Minor Wounds]] [preparada::0] 
	- Touch attack, 1 point of damage.  
- [ ] [[Light (spell)|Light]] [preparada::1] 
	- Object shines like a torch.  
- [ ] [[Mending|Mending]] [preparada::1] 
	- Makes minor repairs on an object.  
- [ ] [[Purify Food and Drink|Purify Food and Drink]] [preparada::0] 
	- Purifies 1 cu. [[ft]]./level of food or water.  
- [ ] [[Read Magic|Read Magic]] [preparada::1] 
	- Read scrolls and spellbooks.  
- [ ] [[Resistance|Resistance]] [preparada::1] 
	- Subject gains +1 on saving throws.  
- [ ] [[Virtue|Virtue]] [preparada::0] 
	- Subject gains 1 temporary hp.  

### Level 01
- [ ] [[Bane|Bane]] [preparada::0] 
	- Enemies take -1 on attack rolls and saves against fear.  
- [ ] [[Bless|Bless]] [preparada::0] 
	- Allies gain +1 on attack rolls and +1 on saves against fear.  
- [ ] [[Bless Water|Bless Water]] [preparada::1] 
	- Makes holy water.  
- [ ] [[Cause Fear|Cause Fear]] [preparada::0] 
	- One creature of 5 HD or less flees for 1d4 rounds.  
- [ ] [[Command|Command]] [preparada::1] 
	- One subject obeys selected command for 1 round.  
- [ ] [[Comprehend Languages|Comprehend Languages]] [preparada::1] 
	- You understand all spoken and written languages.  
- [ ] [[Cure Light Wounds|Cure Light Wounds]] [preparada::0] 
	- Cures 1d8 damage +1/level (max +5).  
- [ ] [[Detect Chaos|Detect Chaos]] [preparada::0] 
	- Reveals creatures, spells, or objects of selected alignment.  
- [ ] [[Detect Evil|Detect Evil]] [preparada::0] 
	- Reveals creatures, spells, or objects of selected alignment.  
- [ ] [[Detect Good|Detect Good]] [preparada::0] 
	- Reveals creatures, spells, or objects of selected alignment.  
- [ ] [[Detect Law|Detect Law]] [preparada::0] 
	- Reveals creatures, spells, or objects of selected alignment.  
- [ ] [[Detect Undead|Detect Undead]] [preparada::0] 
	- Reveals undead within 60 [[ft]].  
- [ ] [[Divine Favor|Divine Favor]] [preparada::0] 
	- You gain +1 per three levels on attack and damage rolls.  
- [ ] [[Doom|Doom]] [preparada::0] 
	- One subject takes -2 on attack rolls, saves, and checks.  
- [ ] [[Endure Elements|Endure Elements]] [preparada::1] 
	- Exist comfortably in hot or cold environments.  
- [ ] [[Entropic Shield|Entropic Shield]] [preparada::0] 
	- Ranged attacks against you have 20% miss chance.  
- [ ] [[Hide from Undead|Hide from Undead]] [preparada::0] 
	- Undead can’t perceive one subject/level.  
- [ ] [[Inflict Light Wounds|Inflict Light Wounds]] [preparada::0] 
	- Touch deals 1d8 damage +1/level (max +5).  
- [ ] [[Magic Stone|Magic Stone]] [preparada::0] 
	- Three stones gain +1 on attack rolls, deal 1d6+1 damage.  
- [ ] [[Magic Weapon|Magic Weapon]] [preparada::0] 
	- Weapon gains +1 bonus.  
- [ ] [[Obscuring Mist|Obscuring Mist]] [preparada::1] 
	- Fog surrounds you.  
- [ ] [[Protection from Chaos|Protection from Chaos]] [preparada::0] 
	- +2 to AC and saves, counter mind control, hedge out elementals and outsiders.  
- [ ] [[Protection from Evil|Protection from Evil]] [preparada::0] 
	- +2 to AC and saves, counter mind control, hedge out elementals and outsiders.  
- [ ] [[Protection from Law|Protection from Law]] [preparada::0] 
	- +2 to AC and saves, counter mind control, hedge out elementals and outsiders.  
- [ ] [[Remove Fear|Remove Fear]] [preparada::1] 
	- Suppresses fear or gives +4 on saves against fear for one subject + one per four levels.  
- [ ] [[Sanctuary|Sanctuary]] [preparada::0] 
	- Opponents can’t attack you, and you can’t attack.  
- [ ] [[Shield of Faith|Shield of Faith]] [preparada::0] 
	- Aura grants +2 or higher deflection bonus.  
- [ ] [[Summon Monster I|Summon Monster I]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  

### Level 02
- [ ] [[Aid|Aid]] [preparada::0] 
	- +1 on attack rolls and saves against fear, 1d8 temporary hp +1/level (max +10).  
- [ ] [[Align Weapon|Align Weapon]] [preparada::0] 
	- Weapon becomes good, evil, lawful, or chaotic.  
- [ ] [[Augury|Augury]] [preparada::1] 
	- Learns whether an action will be good or bad.  
- [ ] [[Bear's Endurance|Bear's Endurance]] [preparada::0] 
	- Subject gains +4 to Con for 1 min./level.  
- [ ] [[Bull's Strength|Bull's Strength]] [preparada::0] 
	- Subject gains +4 to Str for 1 min./level.  
- [ ] [[Calm Emotions|Calm Emotions]] [preparada::1] 
	- Calms creatures, negating emotion effects.  
- [ ] [[Consecrate|Consecrate]] [preparada::0] 
	- Fills area with positive energy, making undead weaker.  
- [ ] [[Cure Moderate Wounds|Cure Moderate Wounds]] [preparada::0] 
	- Cures 2d8 damage +1/level (max +10).  
- [ ] [[Darkness|Darkness]] [preparada::0] 
	- 20-[[ft]]. radius of supernatural shadow.  
- [ ] [[Death Knell|Death Knell]] [preparada::0] 
	- Kills dying creature; you gain 1d8 temporary hp, +2 to Str, and +1 level.  
- [ ] [[Delay Poison|Delay Poison]] [preparada::0] 
	- Stops poison from harming subject for 1 hour/ level.  
- [ ] [[Eagle's Splendor|Eagle's Splendor]] [preparada::0] 
	- Subject gains +4 to Cha for 1 min./level.  
- [ ] [[Enthrall|Enthrall]] [preparada::0] 
	- Captivates all within 100 [[ft]]. + 10 [[ft]]./level.  
- [ ] [[Find Traps|Find Traps]] [preparada::0] 
	- Notice traps as a rogue does.  
- [ ] [[Gentle Repose|Gentle Repose]] [preparada::0] 
	- Preserves one corpse.  
- [ ] [[Hold Person|Hold Person]] [preparada::0] 
	- Paralyzes one humanoid for 1 round/level.  
- [ ] [[Inflict Moderate Wounds|Inflict Moderate Wounds]] [preparada::0] 
	- Touch attack, 2d8 damage +1/level (max +10).  
- [ ] [[Make Whole|Make Whole]] [preparada::1] 
	- Repairs an object.  
- [ ] [[Owl's Wisdom|Owl's Wisdom]] [preparada::0] 
	- Subject gains +4 to Wis for 1 min./level.  
- [ ] [[Remove Paralysis|Remove Paralysis]] [preparada::0] 
	- Frees one or more creatures from paralysis or slow effect.  
- [ ] [[Resist Energy|Resist Energy]] [preparada::0] 
	- Ignores first 10 (or more) points of damage/attack from specified energy type.  
- [ ] [[Resist Energy|Resist Energy m]] [preparada::0] 
	- Ignores first 10 (or more) points of damage/attack from specified energy type.  
- [ ] [[Restoration, Lesser|Restoration, Lesser]] [preparada::0] 
	- Dispels magical ability penalty or repairs 1d4 ability damage.  
- [ ] [[Shatter|Shatter]] [preparada::0] 
	- Sonic vibration damages objects or crystalline creatures.  
- [ ] [[Shield Other|Shield Other]] [preparada::0] 
	- You take half of subject’s damage.  
- [ ] [[Silence|Silence]] [preparada::1] 
	- Negates sound in 20-[[ft]]. radius.  
- [ ] [[Sound Burst|Sound Burst]] [preparada::0] 
	- Deals 1d8 sonic damage to subjects; may stun them.  
- [ ] [[Spiritual Weapon|Spiritual Weapon]] [preparada::0] 
	- Magic weapon attacks on its own.  
- [ ] [[Status|Status]] [preparada::1] 
	- Monitors condition, position of allies.  
- [ ] [[Summon Monster II|Summon Monster II]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Undetectable Alignment|Undetectable Alignment]] [preparada::0] 
	- Conceals alignment for 24 hours.  
- [ ] [[Zone of Truth|Zone of Truth]] [preparada::0] 
	- Subjects within range cannot lie.  

### Level 03
- [ ] [[Bestow Curse|Bestow Curse]] [preparada::0] 
	- -6 to an ability score; -4 on attack rolls, saves, and checks; or 50% chance of losing each action.  
- [ ] [[Blindness_Deafness m|Blindness_Deafness]] [preparada::0] 
	- Makes subject blind or deaf.  
- [ ] [[Continual Flame|Continual Flame]] [preparada::0] 
	- Makes a permanent, heatless torch.  
- [ ] [[Create Food and Water|Create Food and Water]] [preparada::0] 
	- Feeds three humans (or one horse)/level.  
- [ ] [[Cure Serious Wounds|Cure Serious Wounds]] [preparada::0] 
	- Cures 3d8 damage +1/level (max +15).  
- [ ] [[Daylight|Daylight]] [preparada::1] 
	- 60-[[ft]]. radius of bright light.  
- [ ] [[Deeper Darkness|Deeper Darkness]] [preparada::0] 
	- Object sheds supernatural shadow in 60-[[ft]]. radius.  
- [ ] [[Dispel Magic|Dispel Magic]] [preparada::1] 
	- Cancels magical spells and effects.  
- [ ] [[Glyph of Warding|Glyph of Warding]] [preparada::0] 
	- Inscription harms those who pass it.  
- [ ] [[Helping Hand|Helping Hand]] [preparada::0] 
	- Ghostly hand leads subject to you.  
- [ ] [[Inflict Serious Wounds|Inflict Serious Wounds]] [preparada::0] 
	- Touch attack, 3d8 damage +1/level (max +15).  
- [ ] [[Invisibility Purge|Invisibility Purge]] [preparada::0] 
	- Dispels invisibility within 5 [[ft]]./level.  
- [ ] [[Locate Object|Locate Object]] [preparada::0] 
	- Senses direction toward object (specific or type).  
- [ ] [[Magic Circle against Chaos|Magic Circle against Chaos]] [preparada::0] 
	- As protection from chaos, but 10-[[ft]]. radius and 10 min./level.  
- [ ] [[Magic Circle against Evil|Magic Circle against Evil]] [preparada::0] 
	- As protection from evil, but 10-[[ft]]. radius and 10 min./level.  
- [ ] [[Magic Circle against Law|Magic Circle against Law]] [preparada::0] 
	- As protection spells, but 10-[[ft]]. radius and 10 min./level.  
- [ ] [[Magic Vestment|Magic Vestment]] [preparada::0] 
	- Armor or shield gains +1 enhancement per four levels.  
- [ ] [[Meld into Stone|Meld into Stone]] [preparada::0] 
	- You and your gear merge with stone.  
- [ ] [[Obscure Object|Obscure Object]] [preparada::0] 
	- Masks object against scrying.  
- [ ] [[Prayer|Prayer]] [preparada::0] 
	- Allies +1 bonus on most rolls, enemies -1 penalty.  
- [ ] [[Protection from Energy|Protection from Energy]] [preparada::0] 
	- Absorb 12 points/level of damage from one kind of energy.  
- [ ] [[Remove Blindness_Deafness|Remove Blindness_Deafness]] [preparada::0] 
	- Cures normal or magical conditions.  
- [ ] [[Remove Blindness_Deafness|Remove Blindness_Deafness m]] [preparada::0] 
	- ** Cures normal or magical conditions.  
- [ ] [[Remove Curse|Remove Curse]] [preparada::1] 
	- Frees object or person from curse.  
- [ ] [[Remove Disease|Remove Disease]] [preparada::0] 
	- Cures all diseases affecting subject.  
- [ ] [[Searing Light|Searing Light]] [preparada::0] 
	- Ray deals 1d8/two levels damage, more against undead.  
- [ ] [[Speak with Dead|Speak with Dead]] [preparada::0] 
	- Corpse answers one question/two levels.  
- [ ] [[Stone Shape|Stone Shape]] [preparada::1] 
	- Sculpts stone into any shape.  
- [ ] [[Summon Monster III|Summon Monster III]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Telepathic Bond, Lesser|Telepathic Bond, Lesser]] [preparada::0] 
	-  
- [ ] [[Water Breathing|Water Breathing]] [preparada::0] 
	- Subjects can breathe underwater.  
- [ ] [[Water Walk|Water Walk]] [preparada::0] 
	- Subject treads on water as if solid.  
- [ ] [[Wind Wall|Wind Wall]] [preparada::0] 
	- Deflects arrows, smaller creatures, and gases.  

### Level 04
- [ ] [[Air Walk|Air Walk]] [preparada::0] 
	- Subject treads on air as if solid (climb at 45-degree angle).  
- [ ] [[Control Water|Control Water]] [preparada::0] 
	- Raises or lowers bodies of water.  
- [ ] [[Cure Critical Wounds|Cure Critical Wounds]] [preparada::0] 
	- Cures 4d8 damage +1/level (max +20).  
- [ ] [[Death Ward|Death Ward]] [preparada::0] 
	- Grants immunity to death spells and negative energy effects.  
- [ ] [[Dimensional Anchor|Dimensional Anchor]] [preparada::0] 
	- Bars extradimensional movement.  
- [ ] [[Discern Lies|Discern Lies]] [preparada::1] 
	- Reveals deliberate falsehoods.  
- [ ] [[Dismissal|Dismissal]] [preparada::0] 
	- Forces a creature to return to native plane.  
- [ ] [[Divination m|Divination]] [preparada::0] 
	- Provides useful advice for specific proposed actions.  
- [ ] [[Divine Power|Divine Power]] [preparada::0] 
	- You gain attack bonus, +6 to Str, and 1 hp/level.  
- [ ] [[Dweomer of Transference|Dweomer of Transference]] [preparada::0] 
	-  
- [ ] [[Freedom of Movement|Freedom of Movement]] [preparada::0] 
	- Subject moves normally despite impediments.  
- [ ] [[Giant Vermin|Giant Vermin]] [preparada::0] 
	- Turns centipedes, scorpions, or spiders into giant vermin.  
- [ ] [[Imbue with Spell Ability|Imbue with Spell Ability]] [preparada::1] 
	- Transfer spells to subject.  
- [ ] [[Inflict Critical Wounds|Inflict Critical Wounds]] [preparada::0] 
	- Touch attack, 4d8 damage +1/level (max +20).  
- [ ] [[Magic Weapon, Greater|Magic Weapon, Greater]] [preparada::0] 
	- +1/four levels (max +5).  
- [ ] [[Neutralize Poison|Neutralize Poison]] [preparada::0] 
	- Immunizes subject against poison, detoxifies venom in or on subject.  
- [ ] [[Planar Ally, Lesser|Planar Ally, Lesser]] [preparada::0] 
	- Exchange services with a 6 HD extraplanar creature.  
- [ ] [[Planar Ally, Lesser|Planar Ally, Lesser XP]] [preparada::0] 
	- Exchange services with a 6 HD extraplanar creature.  
- [ ] [[Poison (Spell)|Poison]] [preparada::0] 
	- Touch deals 1d10 Con damage, repeats in 1 min.  
- [ ] [[Repel Vermin|Repel Vermin]] [preparada::0] 
	- Insects, spiders, and other vermin stay 10 [[ft]]. away.  
- [ ] [[Restoration|Restoration]] [preparada::0] 
	- Restores level and ability score drains.  
- [ ] [[Sending|Sending]] [preparada::1] 
	- Delivers short message anywhere, instantly.  
- [ ] [[Spell Immunity|Spell Immunity]] [preparada::0] 
	- Subject is immune to one spell per four levels.  
- [ ] [[Summon Monster IV|Summon Monster IV]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Tongues|Tongues]] [preparada::0] 
	- Speak any language.  

### Level 05
- [ ] [[Atonement XP|Atonement XP]] [preparada::0] 
	- Removes burden of misdeeds from subject.  
- [ ] [[Break Enchantment|Break Enchantment]] [preparada::1] 
	- Frees subjects from enchantments, alterations, curses, and petrification.  
- [ ] [[Command, Greater|Command, Greater]] [preparada::0] 
	- As command, but affects one subject/level.  
- [ ] [[Commune|Commune XP]] [preparada::0] 
	- Deity answers one yes-or-no question/level.  
- [ ] [[Cure Light Wounds, Mass|Cure Light Wounds, Mass ]] [preparada::0] 
	- Cures 1d8 damage +1/level for one creature/level, no two of which can be more than 30 [[ft]]. apart.  
- [ ] [[Dispel Chaos|Dispel Chaos]] [preparada::0] 
	- +4 bonus against attacks by chaotic creatures.  
- [ ] [[Dispel Evil|Dispel Evil]] [preparada::0] 
	- +4 bonus against attacks by evil creatures.  
- [ ] [[Dispel Law|Dispel Law]] [preparada::0] 
	- +4 bonus against attacks by lawful creatures.  
- [ ] [[Disrupting Weapon|Disrupting Weapon]] [preparada::0] 
	- Melee weapon destroys undead.  
- [ ] [[Flame Strike|Flame Strike]] [preparada::0] 
	- Smite foes with divine fire (1d6/level damage).  
- [ ] [[Hallow|Hallow]] [preparada::0] 
	- Designates location as holy.  
- [ ] [[Inflict Light Wounds, Mass|Inflict Light Wounds, Mass]] [preparada::0] 
	- Deals 1d8 damage +1/level to many creatures.  
- [ ] [[Insect Plague|Insect Plague]] [preparada::0] 
	- Locust swarms attack creatures.  
- [ ] [[Mark of Justice|Mark of Justice]] [preparada::0] 
	- Designates action that will trigger curse on subject.  
- [ ] [[Plane Shift|Plane Shift]] [preparada::0] 
	- As many as eight subjects travel to another plane.  
- [ ] [[Psychic Turmoil|Psychic Turmoil]] [preparada::0] 
	-  
- [ ] [[Raise Dead|Raise Dead]] [preparada::0] 
	- Restores life to subject who died as long as one day/level ago.  
- [ ] [[Righteous Might|Righteous Might]] [preparada::0] 
	- Your size increases, and you gain combat bonuses.  
- [ ] [[Scrying (spell)|Scrying]] [preparada::1] 
	- Spies on subject from a distance.  
- [ ] [[Slay Living|Slay Living]] [preparada::0] 
	- Touch attack kills subject.  
- [ ] [[Spell Resistance (spell)|Spell Resistance]] [preparada::0] 
	- Subject gains SR 12 + level.  
- [ ] [[Summon Monster V|Summon Monster V]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Symbol of Sleep|Symbol of Sleep]] [preparada::0] 
	- Triggered rune puts nearby creatures into catatonic slumber.  
- [ ] [[True Seeing|True Seeing]] [preparada::0] 
	- Lets you see all things as they really are.  
- [ ] [[Wall of Stone|Wall of Stone]] [preparada::0] 
	- Creates a stone wall that can be shaped.  

### Level 06
- [ ] [[Animate Objects|Animate Objects]] [preparada::0] 
	- Objects attack your foes.  
- [ ] [[Antilife Shell|Antilife Shell]] [preparada::0] 
	- 10-[[ft]].-radius field hedges out living creatures.  
- [ ] [[Banishment|Banishment]] [preparada::0] 
	- Banishes 2 HD/level of extraplanar creatures.  
- [ ] [[Bear's Endurance, Mass|Bear's Endurance, Mass]] [preparada::0] 
	- As bear’s endurance, affects one subject/level.  
- [ ] [[Blade Barrier|Blade Barrier]] [preparada::0] 
	- Wall of blades deals 1d6/level damage.  
- [ ] [[Bull's Strength, Mass|Bull's Strength, Mass]] [preparada::0] 
	- As bull’s strength, affects one subject/ level.  
- [ ] [[Cure Moderate Wounds, Mass|Cure Moderate Wounds, Mass]] [preparada::0] 
	- Cures 2d8 damage +1/level for many creatures.  
- [ ] [[Dispel Magic, Greater|Dispel Magic, Greater]] [preparada::0] 
	- As dispel magic, but +20 on check.  
- [ ] [[Eagle's Splendor, Mass|Eagle's Splendor, Mass]] [preparada::0] 
	- As eagle’s splendor, affects one subject/level.  
- [ ] [[Find the Path|Find the Path]] [preparada::0] 
	- Shows most direct way to a location.  
- [ ] [[Forbiddance|Forbiddance]] [preparada::0] 
	- Blocks planar travel, damages creatures of different alignment.  
- [ ] [[Geas_Quest|Geas_Quest]] [preparada::0] 
	- As lesser geas, plus it affects any creature.  
- [ ] [[Glyph of Warding, Greater|Glyph of Warding, Greater]] [preparada::0] 
	- As glyph of warding, but up to 10d8 damage or 6th-level spell.  
- [ ] [[Harm|Harm]] [preparada::0] 
	- Deals 10 points/level damage to target.  
- [ ] [[Heal|Heal]] [preparada::0] 
	- Cures 10 points/level of damage, all diseases and mental conditions.  
- [ ] [[Heroes' Feast|Heroes' Feast]] [preparada::0] 
	- Food for one creature/level cures and grants combat bonuses.  
- [ ] [[Heroes' Feast|Heroes' Feast m]] [preparada::0] 
	- ** Food for one creature/level cures and grants combat bonuses.  
- [ ] [[Inflict Moderate Wounds, Mass|Inflict Moderate Wounds, Mass]] [preparada::0] 
	- Deals 2d8 damage +1/level to many creatures.  
- [ ] [[Owl's Wisdom, Mass|Owl's Wisdom, Mass]] [preparada::0] 
	- As owl’s wisdom, affects one subject/ level.  
- [ ] [[Planar Ally|Planar Ally]] [preparada::0] 
	- As lesser planar ally, but up to 12 HD.  
- [ ] [[Planar Ally|Planar Ally XP]] [preparada::0] 
	- ** As lesser planar ally, but up to 12 HD.  
- [ ] [[Summon Monster VI|Summon Monster VI]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Symbol of Fear|Symbol of Fear]] [preparada::0] 
	- Triggered rune panics nearby creatures.  
- [ ] [[Symbol of Persuasion|Symbol of Persuasion]] [preparada::0] 
	- Triggered rune charms nearby creatures.  
- [ ] [[Undeath to Death|Undeath to Death]] [preparada::0] 
	- Destroys 1d4/level HD of undead (max 20d4).  
- [ ] [[Wind Walk|Wind Walk]] [preparada::0] 
	- You and your allies turn vaporous and travel fast.  
- [ ] [[Word of Recall|Word of Recall]] [preparada::0] 
	- Teleports you back to designated place.  

### Level 07
- [ ] [[Control Weather|Control Weather]] [preparada::0] 
	- Changes weather in local area.  
- [ ] [[Cure Serious Wounds, Mass|Cure Serious Wounds, Mass]] [preparada::0] 
	- Cures 3d8 damage +1/level for many creatures.  
- [ ] [[Destruction|Destruction]] [preparada::0] 
	- Kills subject and destroys remains.  
- [ ] [[Dictum|Dictum]] [preparada::0] 
	- Kills, paralyzes, slows, or deafens nonlawful subjects.  
- [ ] [[Ethereal Jaunt|Ethereal Jaunt]] [preparada::0] 
	- You become ethereal for 1 round/level.  
- [ ] [[Holy Word|Holy Word]] [preparada::0] 
	- Kills, paralyzes, blinds, or deafens nongood subjects.  
- [ ] [[Inflict Serious Wounds, Mass|Inflict Serious Wounds, Mass]] [preparada::0] 
	- Deals 3d8 damage +1/level to many creatures.  
- [ ] [[Psychic Turmoil, Greater|Psychic Turmoil, Greater]] [preparada::0] 
	-  
- [ ] [[Refuge|Refuge]] [preparada::0] 
	- Alters item to transport its possessor to you.  
- [ ] [[Regenerate|Regenerate]] [preparada::0] 
	- Subject’s severed limbs grow back, cures 4d8 damage +1/level (max +35).  
- [ ] [[Repulsion|Repulsion]] [preparada::0] 
	- Creatures can’t approach you.  
- [ ] [[Restoration, Greater|Restoration, Greater]] [preparada::0] 
	- As restoration, plus restores all levels and ability scores.  
- [ ] [[Restoration, Greater|Restoration, Greater XP]] [preparada::0] 
	- ** As restoration, plus restores all levels and ability scores.  
- [ ] [[Resurrection|Resurrection]] [preparada::0] 
	- Fully restore dead subject.  
- [ ] [[Scrying, Greater|Scrying, Greater]] [preparada::0] 
	- As scrying, but faster and longer.  
- [ ] [[Summon Monster VII|Summon Monster VII]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Symbol of Stunning|Symbol of Stunning]] [preparada::0] 
	- Triggered rune stuns nearby creatures.  
- [ ] [[Symbol of Weakness|Symbol of Weakness]] [preparada::0] 
	- Triggered rune weakens nearby creatures.  
- [ ] [[Word of Chaos|Word of Chaos]] [preparada::0] 
	- Kills, confuses, stuns, or deafens nonchaotic subjects.  

### Level 08
- [ ] [[Antimagic Field|Antimagic Field]] [preparada::0] 
	- Negates magic within 10 [[ft]].  
- [ ] [[Brain Spider|Brain Spider]] [preparada::0] 
	-  
- [ ] [[Cloak of Chaos|Cloak of Chaos]] [preparada::0] 
	- +4 to AC, +4 resistance, and SR 25 against lawful spells.  
- [ ] [[Cure Critical Wounds, Mass|Cure Critical Wounds, Mass]] [preparada::0] 
	- Cures 4d8 damage +1/level for many creatures.  
- [ ] [[Dimensional Lock|Dimensional Lock]] [preparada::0] 
	- Teleportation and interplanar travel blocked for one day/level.  
- [ ] [[Discern Location|Discern Location]] [preparada::0] 
	- Reveals exact location of creature or object.  
- [ ] [[Earthquake|Earthquake]] [preparada::0] 
	- Intense tremor shakes 80-[[ft]].-radius.  
- [ ] [[Fire Storm|Fire Storm]] [preparada::0] 
	- Deals 1d6/level fire damage.  
- [ ] [[Holy Aura|Holy Aura]] [preparada::0] 
	- +4 to AC, +4 resistance, and SR 25 against evil spells.  
- [ ] [[Inflict Critical Wounds, Mass|Inflict Critical Wounds, Mass]] [preparada::0] 
	- Deals 4d8 damage +1/level to many creatures.  
- [ ] [[Planar Ally, Greater|Planar Ally, Greater]] [preparada::0] 
	- As lesser planar ally, but up to 18 HD.  
- [ ] [[Planar Ally, Greater|Planar Ally, Greater XP]] [preparada::0] 
	- undefined
- [ ] [[Shield of Law|Shield of Law]] [preparada::0] 
	- +4 to AC, +4 resistance, and SR 25 against chaotic spells.  
- [ ] [[Spell Immunity, Greater|Spell Immunity, Greater]] [preparada::0] 
	- As spell immunity, but up to 8th-level spells.  
- [ ] [[Summon Monster VIII|Summon Monster VIII]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[Symbol of Death|Symbol of Death]] [preparada::0] 
	- Triggered rune slays nearby creatures.  
- [ ] [[Symbol of Insanity|Symbol of Insanity]] [preparada::0] 
	- Triggered rune renders nearby creatures insane.  

### Level 09
- [ ] [[Astral Projection|Astral Projection]] [preparada::0] 
	- Projects you and companions onto Astral Plane.  
- [ ] [[Energy Drain|Energy Drain]] [preparada::0] 
	- Subject gains 2d4 negative levels.  
- [ ] [[DNDSRD/35eSRD/Spells/All/Etherealness|Etherealness]] [preparada::0] 
	- Travel to Ethereal Plane with companions.  
- [ ] [[Gate|Gate]] [preparada::0] 
	- Connects two planes for travel or summoning.  
- [ ] [[Gate|Gate XP]] [preparada::0] 
	- ** Connects two planes for travel or summoning.  
- [ ] [[Heal, Mass|Heal, Mass]] [preparada::0] 
	- As heal, but with several subjects.  
- [ ] [[Implosion|Implosion]] [preparada::0] 
	- Kills one creature/round.  
- [ ] [[Miracle|Miracle]] [preparada::0] 
	- Requests a deity’s intercession.  
- [ ] [[Miracle|Miracle XP]] [preparada::0] 
	- ** Requests a deity’s intercession.  
- [ ] [[Soul Bind|Soul Bind]] [preparada::0] 
	- Traps newly dead soul to prevent resurrection.  
- [ ] [[Storm of Vengeance|Storm of Vengeance]] [preparada::0] 
	- Storm rains acid, lightning, and hail.  
- [ ] [[Summon Monster IX|Summon Monster IX]] [preparada::0] 
	- Calls extraplanar creature to fight for you.  
- [ ] [[True Resurrection|True Resurrection]] [preparada::0] 
	- As resurrection, plus remains aren’t needed.  




---
[[personagem]] [[NPC]] 
