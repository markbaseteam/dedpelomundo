---
tipo: NPC
posicionamento: aliado
dg-publish: true
---

# [[Conde Julian]]
**nome**: Julian
**alias**: 
**raça**: humano
**idade**: 
**atividade**: Regente da [[Cidade de Nemis]]
**descrição**: 

### primeiro contato
**local**: Seu castelo em [[Cidade de Nemis|Nemis]]
**circunstância**: quando primeiro chegamos na cidade para lidar com a provavel volta do [[Nemis - O demonio]].

### outras informações
Está ajudando as forças de resistência contra a tirania de [[Hextor]].

---
[[personagem]] [[NPC]] 
