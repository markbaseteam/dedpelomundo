---
tipo: NPC
posicionamento: 
dg-publish: true
---

# [[Tiamat, o dourado]]
**nome**: Tiamat
**alias**: O Dourado
**raça**: Elfo (mas suspeitamos ser um dragão)
**idade**:
**atividade**:
**descrição**: um homem de posse, com roupa dourada ornamentada com pedras preciosas. Extravagante mas amoroso com os amigos

### primeiro contato
**local**: [[Etiei]]
**circunstância**: É amigos dos avós paternos de [[Aladrail]]. Conhecemos ele no jantar na casa deles.

### outras informações
Suspeitamos ser um dragão dourado em forma de elfo.

Prometeu nos ajudar com conselhos e recursos contra [[Jorkman]].
- cada ruby ou esmeralda pode repetir o teste de diplomacia com +1 para conseguirmos recursos

Aconselhou não interagirmos com os gigantes de pedra que moram nas cavernas, mas [[Li]] achou que havia algo estranho no seu conselho.

---
[[personagem]] [[NPC]] 
