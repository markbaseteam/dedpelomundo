---
alias: Tríade
dg-publish: true
---
%%[[DeD pelo mundo]] [[DeD 3.5]] %%
[[Home|Home]] 
# Tríade
Grupo de heróis formado originalmente por [[Li]], [[Aladrail]], e [[Lhoris]], ao qual posteriormente se juntou [[Enoch]], irmão de [[Li]].

Após o grupo derrotar [[Nemis - O demonio]], [[Josias]], um clérigo de [[Pelor]], pediu para seguir [[Enoch]] em sua jornada pela justiça, se tornando, desta forma, parte da Tríade também.

Tríade os três valores principais do grupo:
- Justiça
- Liberdade
- Retribuição
