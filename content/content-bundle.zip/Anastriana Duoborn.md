---
tipo: NPC
posicionamento: 
dg-publish: true
---

# [[Anastriana Duoborn]]
**nome**: Anastriana Duoborn
**raça**: elfo
**idade**: aproximadamente 300 anos (30 em humano)
**atividade**:
**descrição**:

### primeiro contato
**local**: [[Etiei]]
**circunstância**: É avó paterno de [Aladrail](app://obsidian.md/Aladrail), e ao irmos à cidade de [Etiei](app://obsidian.md/Etiei) para ajudarmos com o [Dragao Vermelho](app://obsidian.md/Dragao%20Vermelho) [Jorkman](app://obsidian.md/Jorkman), ficamos hospedados em sua casa.

### outras informações
casada com [[Aramil Duoborn]]
cuida da [[Gedania]]
amiga do [[Tiamat, o dourado]]

![[Aramil Duoborn#^historiaDuoborn]]

---
[[personagem]] [[NPC]] 
