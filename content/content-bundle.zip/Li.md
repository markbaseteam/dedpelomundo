---
dg-publish: true
tipo: jogador
jogador: Henrique
alinhamento:
 - leal
 - bom
classe: Monge
Deus: Heironeous
nivel: 12
HP: 70
AC: 21
Initiative: 3
---
%%
[[personagem]] [[jogadores]]
tags: 
%%
[[Home|Home]] | [[triade|Tríade]] | [[Enoch]] 
# Li
nome: Li Jimbao
Raça: [[Humano]]
Classe: [[Monk|monge]]
Deus: [[Heironeous]]
Alinhamento: Leal Bom
Nível: 11

irmão de [[Enoch]]