---
tipo: jogador
Initiative: 7
AC: 
HP: 
DMG: 12
---
