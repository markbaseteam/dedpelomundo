---
title: Enoch
tags: 
name: Enoch
enableToc: true
enableLinkPreview: true
description: Página sobre a campanha de D&D da tríade
page_title: Enoch
share: true
dg-publish: true
tipo: jogador
jogador: Breno
alinhamento:
 - leal
 - bom
classe: Paladino
Deus: Heironeous
nivel: 12
HP: 88
AC: 25
Initiative: 13
outros_personagens: Josias e Arkantos
---
%%[[personagem]] [[jogadores]]%% 
# Enoch
<span class="rightimg"><span class="smallimg">![[Enoch Paladin35e screenshot.png]]</span></span>Nome completo: Enoch Kimbao
Raça: [[Humano]]
Classe: [[Paladin|Paladino]] da Justiça
Deus: [[Heironeous]]
Alinhamento: Leal Bom
Nível: 12

Irmão: [[Li]]
Animal: [[Arkantos]]

[Ficha](https://docs.google.com/spreadsheets/d/1N_DWE0-fEj9ikydNN_grxt86FTaS__yTqt4nsGQJN5Y/edit#gid=16228907)

### História
Ainda criança, ele e seu irmão [[Li]] ficaram órfãos, foram atacados por uma abominação e encontrados e salvos por um paladino que disse estar a procura de Enoch por ele ser um escolhido de [[Heironeous]] para também se tornar um paladino
Aceitou com a condição de poder levar o seu irmão consigo.
Após algum tempo, se separaram para que Li pudesse se tornar um Monge.
Se reencontraram novamente em [[Mercantenopolis|Mercantenópolis]]


Spell from the Book "Spell Compendium"
AURA OF GLORY
Transmutation
Level: Paladin 2
Components: V, DF
Casting Time: 1 swift action
Area: 10-[[ft]].-radius spread
Duration: Instantaneous
Saving Throw: None
Spell Resistance: No
You invoke the holy words and a soft golden light radiates from you. You feel surer of yourself, bolstered by the power of your beliefs.
You channel divine power into yourself, spreading glory to your comrades. This spell removes any fear effect from all allies within your aura of courage.

%%
### Possíveis talentos
#### Livro do jogador

- corrida
	- Percorre 5 vezes o deslocamento padrão, +4 de bônus nos testes de Saltar no final de uma corrida

- lutar as cegas

- saque rápido

#### talentos de outros livros

- Awsome smite (complete champion)
	- **Description**:Through a combination of sheer muscle and mystical acumen, you can deliver devastating smite attacks.
	- **Prerequisites**: Power Attack, base attack bonus +6, smite ability.
	- **Benefit**: This feat allows the use of three tactical maneuvers, each of which requires that you make a smite attack while using the Power Attack feat (minimum attack penalty –1). You must declare the use of this feat before making the attack roll. You can employ only one of these maneuvers at a time. 
		- *Demolishing Smite*: Your smite attack punches through your enemy’s defenses. For the purpose of this single attack, you can ignore a number of points of damage reduction (except DR/— or DR/epic) up to twice your Charisma bonus (if any). For instance, if your Charisma is 17 (+3 bonus), you ignore 6 points of your target’s damage reduction when making a demolishing smite.
		- *Overwhelming Smite*: Your smite attack can knock an opponent prone. If the attack hits and deals damage, it is treated as though it were also a trip attack. Make a Strength check opposed by the defender’s Strength or Dexterity, with all the normal trip modifi ers (PH 158). A foe that resists is not entitled to make a trip attempt against you in return. You can attempt an overwhelming smite only once per round. 
		- *Seeking Smite*: Your smite attack is uncannily guided to its target. For the purpose of this single attack, you ignore any miss chance your foe might have, though your weapon must still be able to strike the target. Thus, while this maneuver allows you to strike an incorporeal creature unerringly with a magic sword, it does not allow you to strike it with a nonmagical weapon

- Great Charisma [Epic]
	- **Benefit**: Your Charisma increases by 1 point.
	- **Special**: You can gain this feat multiple times. Its effects stack.

- strength of conviction (Exemplars of Evil)
	- **Description**: Each day, you can sacrifice one use of smite evil or smite good to smite a single target regardless of his alignment. You gain no additional bonus on the attack roll, but if you hit the target, you deal a number of extra points of damage equal to your class level

- stand still (eph - Expanded Psionics Handbook)
	- **Description**:You can prevent foes from fleeing or closing.
	- **Prerequisite**: Str 13.
	- **Benefit**: When a foe’s movement out of a square you threaten grants you an attack of opportunity, you can give up that attack and instead attempt to stop your foe in his tracks. Make your attack of opportunity normally. If you hit your foe, he must succeed on a Reflex save against a DC of 10 + your damage roll (the opponent does not actually take damage), or immediately halt as if he had used up his move actions for the round. Since you use the Stand Still feat in place of your attack of opportunity, you can do so only a number of times per round equal to the number of times per round you could make an attack of opportunity (normally just one). *Normal*: Attacks of opportunity cannot halt your foes in their tracks.

- Extra smite (complete warrior)
	- 2 smite/day

- Holy Strike [Epic]
	- **Prerequisites**: Smite evil class feature, any good [alignment](https://www.d20srd.org/srd/description.htm#alignment).
	- **Benefit**: Any weapon you wield is treated as a holy weapon (is good-aligned and deals an extra 2d6 points of damage against creatures of evil [alignment](https://www.d20srd.org/srd/description.htm#alignment)).If the weapon already has an alignment, this feat has no effect on the weapon.%%