---
dg-publish: true
alias: Dárius
tipo: NPC
---
Página em construção

O melhor ferreiro de [[Teia]].
casado com [[Jade, esposa de Darius]] 