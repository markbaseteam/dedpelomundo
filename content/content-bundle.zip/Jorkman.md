---
tipo: NPC
posicionamento: Vilao
dg-publish: true
---
[[Home|Home]] | [[Etiei]] | [[Caverna do Dragão]]
# [[Jorkman]]
<span class="rightimg"><span class="smallimg"> ![[redDragonVilainProfile.jpeg]]</span></span>nome: [[Jorkman]] 
raça: [[Dragao Vermelho]]

### primeiro contato
local: [[Cidade de Nemis]]
circunstância: Ouvimos um boato de que havia um dragão vermelho atacando carruagens

### outras informações
Ao que tudo indica é um [[Dragao Vermelho]] jovem adulto.

Está aterrorizando e extorquindo a cidade élfica de [[Etiei]], e a [[triade|Tríade]] foi chamada para ajudar a cidade a se livrar dele


---
%%[[personagem]] [[NPC]] %%
