---

database-plugin: basic

---

<%%
name: InitiativeTracker
description: para acompanhamento de batalha
columns:
  __file__:
    key: __file__
    input: markdown
    label: File
    accessor: __file__
    isMetadata: true
    skipPersist: false
    isDragDisabled: false
    csvCandidate: true
    position: 1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: true
      source_data: current_folder
  HP:
    input: text
    key: HP
    accessor: HP
    label: HP
    position: 5
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      task_hide_completed: true
  AC:
    input: number
    accessor: AC
    key: AC
    label: AC
    position: 4
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  DMG:
    input: text
    accessor: DMG
    key: DMG
    label: DMG
    position: 6
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  Initiative:
    input: text
    accessor: Initiative
    key: Initiative
    label: Initiative
    position: 3
    isSorted: true
    isSortedDesc: true
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  outros_personagens:
    input: text
    accessor: outros_personagens
    key: outros_personagens
    label: outros personagens
    position: 2
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  nivel:
    input: text
    accessor: nivel
    key: nivel
    label: nivel
    position: 100
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  Condicao:
    input: text
    accessor: Condicao
    key: Condicao
    label: Condicao
    position: 100
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  rodada:
    input: text
    accessor: rodada
    key: rodada
    label: rodada
    position: 100
    skipPersist: false
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
config:
  enable_show_state: false
  group_folder_column: 
  remove_field_when_delete_column: false
  cell_size: compact
  sticky_first_column: true
  show_metadata_created: false
  show_metadata_modified: false
  source_data: current_folder
  source_form_result: root
  show_metadata_tasks: false
  frontmatter_quote_wrap: false
  row_templates_folder: /
  current_row_template: 
filters:
  - {field: tipo, operator: EQUAL, value: jogador}
%%>