---
tipo: NPC
posicionamento: aliado
dg-publish: true
alias: Sumo sacerdote de Nimbi
---
[[Home]] | [[Log Do dia 4720-1-16]] | [[log do dia 4720-1-19]] 

# Salazar, o mendigo
nome: Salazar
![[salazaromendigo.png]]

### primeiro contato
local: ruas de [[Mercantenopolis]]
circunstância: [[Lhoris]] andava para ir investigar um suposto culto de [[Olidamara]]

### outras informações
Ele parece doido, porém já nos passou muitas informações preciosas, como por exemplo que a [[Esplendorosa Biblioteca de Magia]] possuía um 6º andar.

[[Boccob, O velho]] nos disse que ele é uma boa pessoa, mas não é quem diz ser, mas também não é nenhum deus.


---
[[personagem]] [[NPC]] [[DeD pelo mundo]] [[DeD 3.5]] 