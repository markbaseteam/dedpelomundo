---
criado: 2022-04-11
dg-publish: true
posicionamento: Aliado
tipo: NPC
alias:
- o grande mago Mirian
- Mirian, o mago que fez a arma para matar o demonio Nemis
---
[[Home]] | [[Log Do dia 4720-1-16]] | [[Arma da mortalidade]] |

# O grande mago Mirian

O grande mago da antiguidade que fez a [[Arma da mortalidade]], capaz de deixar qualquer ser imortal, mortal, por 1d8 turnos.