---
tipo: NPC
posicionamento: 
dg-publish: true
---

# [[Aramil Duoborn]]
**nome**: Aramil Duoborn
**raça**: elfo
**idade**: aproximadamente 400 anos (40 em humano)
**atividade**:
**descrição**:

### primeiro contato
**local**: [[Etiei]]
**circunstância**: É avô paterno de [[Aladrail]], e ao irmos à cidade de [[Etiei]] para ajudarmos com o [[Dragao Vermelho]] [[Jorkman]], ficamos hospedados em sua casa.

### outras informações
casado com [[Anastriana Duoborn]]
cuida da [[Gedania]]
amigo do [[Tiamat, o dourado]]

Informou que o pai de [[Aladrail]] na verdade foi morto pelos homens de [[Hextor]], e não fugiu como foi dito pelas autoridades.

 Morava em etéia com a família (seu filho, o pai de [[Aladrail]], e cônjuge) quando as tropas de [[Hextor]] descobriu a cidade e quis incorporá-la no império. Mas o regente da cidade não aceitou isso e houve uma guerra. O pai de [[Aladrail]] fugiu logo no início do conflito. Os avós ficaram até a queda da cidade, e quando a cidade caiu [[Tiamat, o dourado]] ajudou eles a acharem [[Etiei]]. ^historiaDuoborn


---
[[personagem]] [[NPC]] 
