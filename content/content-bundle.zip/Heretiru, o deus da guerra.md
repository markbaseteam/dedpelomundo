---
tipo: deus
dg-publish: true
posicionamento: 
---
[[Home]] | [[Log do dia 4720-1-17]] | [[Duelo contra clerigo de Heretiru]] 

# Heretiru, o deus da guerra
Página em construção

Deus da guerra

---
[[DeD pelo mundo]] 
