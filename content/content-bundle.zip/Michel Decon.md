---
tipo: NPC
posicionamento: Hostil
alias: vampiro que nos seguia
dg-publish: true
---
%%
[[personagem]] [[NPC]] [[inimigo]] [[vampiro]] [[monge]] 
tags: 
%%
# Michel Decon
nome: Michel Decon
tipo: Humanoide
raça: Vampiro Humano
classe: Monge Dançarino das sombras

### primeiro contato
local: [[Esplendorosa Biblioteca de Magia]]
circunstância: [[Aladrail]] pecebeu que ele estava nos seguindo. Confrontado ele negou. Foi visto nos seguindo novamente, e acabou fugindo. Na terceira vez rolamos iniciativa

### outras informações
Além de vampiro, ele é um Monge dançarino das sombras

O confrontamos na rua. Sua CA era de 29, mas [[Aladrail]] o derrubou com a magia [[O Riso Histérico de Tasha]]

Após seu PV ficar abaixo de 0, ele passou para o estado gasoso para se recuperar em seu caixão. O seguimos até um hotel no melhor bairro da cidade e lutamos com seus seguranças.