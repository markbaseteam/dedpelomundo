---
tipo: NPC
posicionamento: 
dg-publish: true
---
<a href="javascript:history.back()">⬅️ Voltar</a>
Páginas em contrução
[[Home|Home]] | [[Renia]] | [[Caverna do Dragão]] | [[Log Diario 4720-8-1]] 
# [[Izolda]]
**nome**: Izolda
**alias**: 
**raça**: 
**idade**: 
**atividade**: 
**descrição**: 

### primeiro contato
**local**: 
**circunstância**: 

### outras informações

---
[[personagem]] [[NPC]] 
