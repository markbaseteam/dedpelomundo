---
tipo: NPC
posicionamento: 
dg-publish: true
---
[[Home]] | [[Log do dia 4720-1-17]] | [[Ilitia]] | [[O resgate de Darius]] 

Página em construção

esposa do [[Anão Darius]], considerado o melhor ferreiro de [[Teia]].

---
[[DeD pelo mundo]]