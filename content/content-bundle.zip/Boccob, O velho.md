---
dg-publish: true
---
[[Home]] | [[Log Do dia 4720-1-16]] 

# Boccob, O Velho
Deus médio da magia

página em cosntrução

%%
tags: [[DeD pelo mundo]] [[DeD 3.5]] 
%%