---
dg-publish: true
tipo: jogador
jogador: Nelson
alinhamento:
 - neutro
 - neutro
classe: Ladino
Deus: St Cuthbert
nivel: 12
HP: 63
AC: 19
Initiative: 17
outros_personagens: SilverHawk
Condicao: 
---
%%
[[personagem]] [[jogadores]]
tags: 
%%

# [[Lhoris]]
<span class="rightimg"><span class="mediumimg">![[LhorisProfilePic.jpeg]]</span></span>nome: Lhoris Brynenor
Raça: [[Elfo]]
Classe: [[ladino]]
Deus: [[St Cuthbert]]
Alinhamento: neutro neutro
Nível: 11
<br>
Se aproximou de de [[Aladrail]] dizendo ser seu tio, porém mais tarde revelou que na verdade era um amigo muito próximo do pai dele, mas não é relacionado a ele por sangue.
