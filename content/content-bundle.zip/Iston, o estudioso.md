---
tipo: NPC
posicionamento: 
dg-publish: false
---
[[Home|Home]] | [[Etiei]] | [[Esplendorosa Biblioteca de Magia]] 
# [[Iston, o estudioso]]
**nome**: Iston
**alias**: O estudioso
**raça**: elfo
**idade**: 
**atividade**: bibliotecário em [[Etiei]]
**descrição**: 

### primeiro contato
**local**: [[Etiei]]
**circunstância**: Quando fomos à biblioteca em [[Etiei]] ele se preparava para contar uma história para uma audiência

### outras informações
Apesar de termos encontrado com ele pela primeira vez em [[Etiei]], já haviamos visto uma estátua dele em [[Cidade de Nemis|Nemis]], na [[Grande Biblioteca de história e religião]]. Uma homenagem por ele ter passado aproximadamente 500 anos tentando ler todos os livros lá presentes.


---
[[personagem]] [[NPC]] 
